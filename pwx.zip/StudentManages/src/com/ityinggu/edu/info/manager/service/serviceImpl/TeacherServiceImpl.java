package com.ityinggu.edu.info.manager.service.serviceImpl;


import com.ityinggu.edu.info.manager.dao.TeacherDao;
import com.ityinggu.edu.info.manager.domain.Teacher;
import com.ityinggu.edu.info.manager.load.teacherIdLoad;
import com.ityinggu.edu.info.manager.service.TeacherService;

import java.util.List;

public class TeacherServiceImpl implements TeacherService {

        TeacherDao teacherDao =new TeacherDao();

    /**+
     * 学生信息查询
     * @param name
     * @return
     */
    @Override
    public List<Teacher> TeacherFind(String name) {

        if (name==null){
            return teacherDao.findAll();
        }else {
            teacherDao.findName(name);

            return teacherDao.findName(name);
        }

    }

    /**
     * 学生信息新增
     * @param list
     * @return
     */
    @Override
    public int TeacherAdd(List<String> list) {

        Teacher teacher = new Teacher();
        teacher.setId(String.valueOf(teacherIdLoad.getCurrentId()));
        teacher.setName(list.get(0));
        teacher.setAge(list.get(1));
        teacher.setBirthday(list.get(2));
        return teacherDao.save(teacher);


    }

    /**
     * 学生信息修改
     * @param list<String>
     * @param Id
     * @return
     */
    @Override
    public int TeacherUpdate(String Id, List<String> list) {
        Teacher teacher = new Teacher();
        teacher.setId(Id);
        teacher.setName(list.get(0));
        teacher.setAge(list.get(1));
        teacher.setBirthday(list.get(2));
        return teacherDao.updateById(teacher);
    }

    /**
     * 学生信息删除
     * @param Id
     * @return
     */
    @Override
    public int TeacherDelete(String Id) {


        return teacherDao.deleteById(Id);
    }

    /**
     * 根据学生id查询信息
     * @param id
     * @return
     */
    @Override
    public List<Teacher> TeacherFindById(String id) {

        return teacherDao.getById(id);

    }
}
