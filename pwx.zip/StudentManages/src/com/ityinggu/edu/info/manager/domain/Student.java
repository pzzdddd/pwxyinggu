package com.ityinggu.edu.info.manager.domain;


public class Student {
    private String id;
    private String name;
    private String age;
    private String birthday;
    String address;

    public Student() {
    }

    public Student(String id, String name, String age, String birthday) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.birthday = birthday;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getAge() {
        return age;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    @Override
    public String toString() {
        return "学生信息[" +
                "学生ID='" + id + '\'' +
                ", 姓名='" + name + '\'' +
                ", 年龄='" + age + '\'' +
                ", 生日='" + birthday + '\'' +
                ']';
    }
}
