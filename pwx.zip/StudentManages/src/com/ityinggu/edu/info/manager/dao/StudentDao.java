package com.ityinggu.edu.info.manager.dao;

import com.ityinggu.edu.info.manager.domain.Student;

import java.util.ArrayList;
import java.util.List;

public class StudentDao {
    //数据持久层开发
    List<Student> studentsList= new ArrayList<>();;

    /**
     * 学生新增操作
     * @param student
     * @return
     */
    public int save(Student student) {


        boolean add = studentsList.add(student);
        if (add){
            return 1;
        }else {
            return 0;
        }
    }


    public List<Student> findAll() {
        return studentsList;
    }

    public List<Student> findName(String name) {
        List<Student> list= new ArrayList<>();;
        for (Student studnet:studentsList) {
            if (studnet.getName().equals(name))
            {
                list.add(studnet);
            }

        }
        return list;
    }

    public List<Student> getById(String id) {

        List<Student> list= new ArrayList<>();;
        for (Student studnet:studentsList) {
            if (studnet.getId().equals(id))
            {
                list.add(studnet);
            }

        }
        return list;
    }

    public int updateById(Student student) {

        for (int i = 0; i < studentsList.size(); i++) {
            if (studentsList.get(i).getId().equals(student.getId())){
                 studentsList.set(i, student);
                return 1;
            }
        }
       return 0;
    }

    public int deleteById(String id) {
        for (int i = 0; i < studentsList.size(); i++) {
            if (studentsList.get(i).getId().equals(id)){
                studentsList.remove(i);
                return 1;
            }
        }
        return 0;
    }
}
