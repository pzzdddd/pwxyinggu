package com.ityinggu.edu.info.manager.service;

import com.ityinggu.edu.info.manager.domain.Student;
import com.ityinggu.edu.info.manager.domain.Teacher;

import java.util.List;

public interface TeacherService {

    List<Teacher> TeacherFind (String name);

    int TeacherAdd (List<String> list);

    int TeacherUpdate(String Id, List<String> list);

    int TeacherDelete(String Id);

    List<Teacher> TeacherFindById(String id);
}
