package com.ityinggu.edu.info.manager.controller;

import com.ityinggu.edu.info.manager.domain.Student;
import com.ityinggu.edu.info.manager.domain.Student;
import com.ityinggu.edu.info.manager.service.serviceImpl.StudentServiceImpl;

import java.util.*;

public class StudentController {


    /**
     * 用户输入判断以及对用户输入校验
     */

    public String IputIn(){

        Scanner scanner = new Scanner(System.in);
        String in = null;
        try {
            in = scanner.next();

        } catch (Exception e) {
            throw new IllegalArgumentException("非法参数异常");

        }
        return in;
    }

    /**
     * 学生管理系统增删改查
     */
    public  void  StudentCUID() {
        /**
         *  用户输入界面以及操作提示！
         */
        StudentServiceImpl studentService = new StudentServiceImpl();
        while (true){

            System.out.println("欢迎登录学生管理系统！\n请输入需要操作的指令：查询|新增|修改|删除|退出！");
            String in = IputIn();
            String name = null;

            if (in.equals("查询")) {
                //数据查询业务
                System.out.println("您需要查询所有学生则输入”所有学生“，要查询指定学生则输入学生姓名！");
                name= IputIn();
                    if (name.equals("所有学生") || name == null) {
                        name = null;
                    }
                    List<Student> studentfind = studentService.StudentFind(name);
                    if (studentfind.size() > 0) {
                        for (Student stu : studentfind) {
                            System.out.println(stu.toString());
                        }
                        System.out.println("查询信息成功");
                    } else {
                        System.out.println("查询信息失败，暂无此人");
                    }

            } else if (in.equals("新增")) {
                //数据查询业务
                System.out.println("请输入学生姓名，年龄，生日（1999-2-10）");
                name = IputIn();
                List<String> list= Arrays.asList(name.split("，"));
                while (!(list.size()==3))
                {
                    System.out.println("请输入完整数据");
                    name = IputIn();
                    list= Arrays.asList(name.split("，"));
                }
                    String nameFind = list.get(0);
                    List<Student> studentfind = studentService.StudentFind(nameFind);
                    int studentadd = studentService.StudentAdd(list);
                    if (studentadd>0){
                        System.out.println("新增学生成功");

                    }else {
                        System.out.println("学生新增失败");
                    }


            } else if (in.equals("删除")) {
                //数据删除业务（根据学生id删除）
                System.out.println("请输入需要删除的学生的ID");
                String Id = IputIn();
                List<Student> listSize = studentService.StudentFindById(Id);
                while (listSize.size()<=0){
                    System.out.println("请重新输入需要修改的学生的ID或输入退出，退出当前模块！");
                    Id = IputIn();
                    listSize = studentService.StudentFindById(Id);
                    if(Id.equals("退出")){
                        break;
                    }
                }
                if(listSize.size()>0){
                    int i = studentService.StudentDelete(Id);
                    if (i>0){
                        System.out.println("删除信息成功");
                    }else {
                        System.out.println("删除信息失败");
                    }
                }else {
                    System.out.println("不存在此Id的学生请重新输入");
                }

            } else if (in.equals("修改")) {
                System.out.println("请输入需要修改的学生的ID");
                String Id = IputIn();
                List<Student> listSize = studentService.StudentFindById(Id);
                while (listSize.size()<=0){
                    System.out.println("请重新输入需要修改的学生的ID或输入退出，退出当前模块！");
                    Id = IputIn();
                    listSize = studentService.StudentFindById(Id);
                    if(Id.equals("退出")){
                        break;
                    }
                }
                System.out.println("请输入学生姓名，年龄，生日（1999-2-10）");
                String Data = IputIn();
                List<String> listData=Arrays.asList(Data.split("，"));
                while (!(listData.size()==3)) {
                    System.out.println("请输入正确数据！");
                    name = IputIn();
                    listData = Arrays.asList(name.split("，"));
                }
                int studentupdate = studentService.StudentUpdate(Id,listData);
                if (studentupdate>0){
                    System.out.println("学生信息修改成功！");
                }else{
                    System.out.println("修改失败");
                }
            } else if (in.equals("退出")) {
                //数据查询业务
                System.out.println("退出学生管理系统！");
                break;

            }

        }
    }



}
