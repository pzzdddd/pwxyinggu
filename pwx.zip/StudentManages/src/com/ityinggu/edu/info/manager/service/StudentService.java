package com.ityinggu.edu.info.manager.service;

import com.ityinggu.edu.info.manager.domain.Student;

import java.util.List;

public interface StudentService {

    List<Student> StudentFind (String name);

    int StudentAdd (List<String> list);

    int StudentUpdate(String Id, List<String> list);

    int StudentDelete(String Id);

    List<Student> StudentFindById(String id);
}
