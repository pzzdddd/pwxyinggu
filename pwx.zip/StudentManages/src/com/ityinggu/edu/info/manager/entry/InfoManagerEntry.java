package com.ityinggu.edu.info.manager.entry;

import com.ityinggu.edu.info.manager.controller.StudentController;
import com.ityinggu.edu.info.manager.controller.TeacherController;

import java.util.Scanner;

/**
 * 主函数入口
 */
public class InfoManagerEntry {

    public static void main(String[] args) {
        StudentController studentController = new StudentController();
        TeacherController teacherController = new TeacherController();
        while (true) {
            System.out.println("欢迎登录管理页面！\n 输入1进入学生管理系统！，输入2进入教师管理页面！，输入3退出本系统");
            Scanner scanner = new Scanner(System.in);
            int i = scanner.nextInt();
            switch (i) {
                case 1:
                studentController.StudentCUID();
                    break;
                case 2 :
                teacherController.TeacherCUID();
                    break;
                case 3:
                    System.exit(0);
                    break;
                default:
                    System.out.println("请重新输入正确的值！"); break;
            }

        }
    }


}
