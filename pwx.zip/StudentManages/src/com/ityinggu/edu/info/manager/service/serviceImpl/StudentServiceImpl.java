package com.ityinggu.edu.info.manager.service.serviceImpl;

import com.ityinggu.edu.info.manager.dao.StudentDao;
import com.ityinggu.edu.info.manager.domain.Student;
import com.ityinggu.edu.info.manager.load.BaseLoad;
import com.ityinggu.edu.info.manager.service.StudentService;

import java.util.List;

/**
 * 实现学生cuid
 */
public class StudentServiceImpl implements StudentService {
     StudentDao studentDao =new StudentDao();

    /**+
     * 学生信息查询
     * @param name
     * @return
     */
    @Override
    public List<Student> StudentFind(String name) {

        if (name==null){
            return studentDao.findAll();
        }else {
            studentDao.findName(name);

            return studentDao.findName(name);
        }

    }

    /**
     * 学生信息新增
     * @param list
     * @return
     */
    @Override
    public int StudentAdd(List<String> list) {

        Student student = new Student();
        student.setId(String.valueOf(BaseLoad.getCurrentId()));
        student.setName(list.get(0));
        student.setAge(list.get(1));
        student.setBirthday(list.get(2));
         return studentDao.save(student);


    }

    /**
     * 学生信息修改
     * @param list<String>
     * @param Id
     * @return
     */
    @Override
    public int StudentUpdate(String Id, List<String> list) {
        Student student = new Student();
        student.setId(Id);
        student.setName(list.get(0));
        student.setAge(list.get(1));
        student.setBirthday(list.get(2));
        return studentDao.updateById(student);
    }

    /**
     * 学生信息删除
     * @param Id
     * @return
     */
    @Override
    public int StudentDelete(String Id) {


        return studentDao.deleteById(Id);
    }

    /**
     * 根据学生id查询信息
     * @param id
     * @return
     */
    @Override
    public List<Student> StudentFindById(String id) {

     return studentDao.getById(id);

    }
}
