package com.ityinggu.edu.info.manager.load;

public class BaseLoad {
    public static Long current=0L;


    public static Long getCurrentId() {
        return  ++current;

    }
    public static void restCurrentId() {
        current=0L;
    }

}
