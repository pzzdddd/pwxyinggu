package com.ityinggu.edu.info.manager.dao;

import com.ityinggu.edu.info.manager.domain.Teacher;

import java.util.ArrayList;
import java.util.List;

public class TeacherDao {
    List<Teacher> teachersList= new ArrayList<>();;

    /**
     * 学生新增操作
     * @param teacher
     * @return
     */
    public int save(Teacher teacher) {


        boolean add = teachersList.add(teacher);
        if (add){
            return 1;
        }else {
            return 0;
        }
    }


    public List<Teacher> findAll() {
        return teachersList;
    }

    public List<Teacher> findName(String name) {
        List<Teacher> list= new ArrayList<>();;
        for (Teacher studnet:teachersList) {
            if (studnet.getName().equals(name))
            {
                list.add(studnet);
            }

        }
        return list;
    }

    public List<Teacher> getById(String id) {

        List<Teacher> list= new ArrayList<>();;
        for (Teacher studnet:teachersList) {
            if (studnet.getId().equals(id))
            {
                list.add(studnet);
            }

        }
        return list;
    }

    public int updateById(Teacher teacher) {

        for (int i = 0; i < teachersList.size(); i++) {
            if (teachersList.get(i).getId().equals(teacher.getId())){
                teachersList.set(i, teacher);
                return 1;
            }
        }
        return 0;
    }

    public int deleteById(String id) {
        for (int i = 0; i < teachersList.size(); i++) {
            if (teachersList.get(i).getId().equals(id)){
                teachersList.remove(i);
                return 1;
            }
        }
        return 0;
    }
}
