package com.ityinggu.edu.info.manager.controller;

import com.ityinggu.edu.info.manager.domain.Teacher;

import com.ityinggu.edu.info.manager.service.serviceImpl.TeacherServiceImpl;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class TeacherController {
    public String IputIn(){

        Scanner scanner = new Scanner(System.in);
        String in = null;
        try {
            in = scanner.next();

        } catch (Exception e) {
            throw new IllegalArgumentException("非法参数异常");

        }
        return in;
    }

    public  void  TeacherCUID() {
        /**
         *  用户输入界面以及操作提示！
         */
        TeacherServiceImpl teacherService = new TeacherServiceImpl();
        while (true){

            System.out.println("欢迎登录教师管理系统！\n请输入需要操作的指令：查询|新增|修改|删除|退出！");
            String in = IputIn();
            String name = null;

            if (in.equals("查询")) {
                //数据查询业务
                System.out.println("您需要查询所有老师则输入”所有老师“，要查询指定老师则输入老师姓名！");
                name= IputIn();
                    //显示所有老师的信息

                    if (name.equals("所有老师")||name ==null){
                        name =null;
                    }
                    List<Teacher> teacherfind = teacherService.TeacherFind(name);
                    if(teacherfind.size()>0) {
                        for (Teacher stu : teacherfind) {
                            System.out.println(stu.toString());
                        } System.out.println("查询信息成功");
                    }else {
                        System.out.println("查询信息失败，暂无此人");
                    }

            } else if (in.equals("新增")) {
                //数据查询业务
                System.out.println("请输入老师姓名，年龄，生日（1999-2-10）");
                name = IputIn();
                List<String> list= Arrays.asList(name.split("，"));
                while (!(list.size()==3))
                {
                    System.out.println("请输入正确数据！");
                    name = IputIn();
                    list= Arrays.asList(name.split("，"));
                }
                String nameFind = list.get(0);
                List<Teacher> teacherfind = teacherService.TeacherFind(nameFind);
                int teacheradd = teacherService.TeacherAdd(list);
                if (teacheradd>0){
                    System.out.println("新增老师成功");

                }else {
                    System.out.println("老师新增失败");
                }


            } else if (in.equals("删除")) {
                //数据删除业务（根据老师id删除）
                System.out.println("请输入需要删除的老师的ID");
                String Id = IputIn();
                List<Teacher> listSize = teacherService.TeacherFindById(Id);
                while (listSize.size()<=0){
                    System.out.println("请重新输入需要修改的老师的ID或输入退出，退出当前模块！");
                    Id = IputIn();
                    listSize = teacherService.TeacherFindById(Id);
                    if(Id.equals("退出")){
                        break;
                    }
                }
                if(listSize.size()>0){
                    int i = teacherService.TeacherDelete(Id);
                    if (i>0){
                        System.out.println("删除信息成功");
                    }else {
                        System.out.println("删除信息失败");
                    }
                }else {
                    System.out.println("不存在此Id的老师请重新输入");
                }

            } else if (in.equals("修改")) {
                System.out.println("请输入需要修改的老师的ID");
                String Id = IputIn();
                List<Teacher> listSize = teacherService.TeacherFindById(Id);
                while (listSize.size()<=0){
                    System.out.println("请重新输入需要修改的老师的ID或输入退出，退出当前模块！");
                    Id = IputIn();
                    listSize = teacherService.TeacherFindById(Id);
                    if(Id.equals("退出")){
                        break;
                    }
                }
                System.out.println("请输入老师姓名，年龄，生日（1999-2-10）");
                String Data = IputIn();
                List<String> listData=Arrays.asList(Data.split("，"));
                while (!(listData.size()==3)) {
                    System.out.println("请输入正确数据！");
                    name = IputIn();
                    listData = Arrays.asList(name.split("，"));
                }
                    int teacherupdate = teacherService.TeacherUpdate(Id,listData);
                    if (teacherupdate>0){
                        System.out.println("老师信息修改成功！");
                    }else{
                        System.out.println("修改失败");
                    }
            } else if (in.equals("退出")) {
                //数据查询业务
                System.out.println("退出教师管理系统");
                break;

            }

        }
    }
}
